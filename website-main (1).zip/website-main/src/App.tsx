import { useState } from 'react'
import { Hero } from './components/Hero';

import './App.css'

function App() {

  return (
    <>
      <div>
        <Hero/>
      </div>
    </>
  )
}

export default App
